﻿using Microsoft.AspNetCore.Mvc;

namespace AspNetCoreDemo.Controllers.MVC
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }
    }
}
