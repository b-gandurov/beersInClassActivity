﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AspNetCoreDemo.Tests.Controllers.BeersApiControllerTests
{
    [TestClass]
    public class Delete_Should
    {
        //ToDo
    }
}
